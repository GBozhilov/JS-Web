module.exports = {
    development: {
        connectionString: 'mongodb://localhost:27017/MongoPlayground',
        port: 3000
    },
    production: {
        
    }
};