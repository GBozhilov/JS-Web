let Tag = require('./../models/Tag');
let Image = require('./../models/Image');
const fs = require('fs');

module.exports = (req, res) => {
    if (req.pathname === '/' && req.method === 'GET') {
        fs.readFile('./views/index.html', (err, data) => {
            if (err) {
                console.log(err);
                return;
            }
            res.writeHead(200, {
                'Content-Type': 'text/html'
            });
            let displayTags = '';

            Tag.find({}).then(tags => {
                for (let tag of tags) {
                    displayTags += `<div class='tag' id="${tag._id}">${tag.tagName}</div>`;
                }

                data = data
                    .toString()
                    .replace('<div class=\'replaceMe\'></div>', displayTags);
        
                res.end(data);
            });
        });
    } else {
        return true;
    }
};