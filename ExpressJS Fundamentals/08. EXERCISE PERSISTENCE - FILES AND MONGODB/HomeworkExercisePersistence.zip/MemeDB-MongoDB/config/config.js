module.exports = {
    development: {
        connectionString: 'mongodb://localhost:27017/Memes',
        port: 3000
    },
    production: {
        
    }
};